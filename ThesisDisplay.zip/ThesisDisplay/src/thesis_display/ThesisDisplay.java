package thesis_display;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;

public class ThesisDisplay extends JPanel implements ActionListener {

	static Timer tm = new Timer(5, null);
	public int x = 900, y = 400, xOrigin = 900, yOrigin = 900, velX, velY, zAngle = 0, newXOrigin = 900,
			newYOrigin = 900;
	public int incrementor = 1;

	public static Scanner reader = new Scanner(System.in);
	public static JSlider orientation = new JSlider(JSlider.HORIZONTAL, -180, 180, 0);
	public static JSlider speed = new JSlider(JSlider.HORIZONTAL, 1, 11, 5);

	static int xMessage, yMessage, xLength = 30, yLength = 30;
	public static ArrayList<MessageDisplay> trueLEDList;
	public static MessageDisplay[] trueLEDArray;



	public void paintComponent(Graphics LEDStrip) {
		super.paintComponent(LEDStrip);
		LEDStrip.setColor(Color.BLACK);
		Line2D line = new Line2D.Double(newXOrigin, newYOrigin, x, y);
		Rectangle2D rect = new Rectangle2D.Double(220, 220, 280, 280);

		Graphics2D g2d = (Graphics2D) LEDStrip.create();
		g2d.draw(rect);
		g2d.draw(line);
		LEDStrip.setColor(Color.WHITE);
		for (int i = 0; i < trueLEDArray.length; i++) {
			g2d.setColor(Color.WHITE);
			Rectangle2D rectNode = new Rectangle2D.Double(trueLEDArray[i].x, trueLEDArray[i].y, 20, 20);
			if (line.intersects(rectNode)) {
				g2d.setColor(Color.RED);
				g2d.fill(rectNode);
			}
			g2d.draw(rectNode);
		}

		LEDStrip.drawLine(520, 520, 220, 520);
		LEDStrip.drawLine(220, 520, 220, 220);
		LEDStrip.drawLine(220, 220, 520, 220);
		LEDStrip.drawLine(500, 220, 500, 520);
		g2d.dispose();
	}

	public void actionPerformed(ActionEvent e) {

		tm.setDelay(speed.getValue());
		if (tm.getDelay() == 11) {
			incrementor = 0;
		}

		if (zAngle > (orientation.getValue() + 90)) {
			incrementor = -1;
		}
		if (zAngle < (orientation.getValue() - 90)) {
			incrementor = 1;
		}

		zAngle += incrementor;

		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				newXOrigin = e.getX();
				newYOrigin = e.getY();
			}
		});

		addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseDragged(MouseEvent e) {
				newXOrigin = e.getX();
				newYOrigin = e.getY();
			}
		});

		x = (int) (newXOrigin + 600 * Math.sin(Math.toRadians(180 - zAngle)));
		y = (int) (newYOrigin + 600 * Math.cos(Math.toRadians(180 - zAngle)));

		repaint();

	}

	public static boolean[][] userInputMatrix() {
		boolean[][] userMatrix = new boolean[yLength][xLength];
		for (int a = 5; a < 20; a++) {
			for (int b = 5; b < 20; b++) {
				userMatrix[a][b] = true;
			}
		}

		return userMatrix;
	}

	public static void findTrueLED() {
		trueLEDList = new ArrayList<MessageDisplay>();
		boolean[][] LEDMatrix = userInputMatrix();
		for (int i = 0; i < yLength; i++) {
			for (int j = 0; j < xLength; j++) {
				if (LEDMatrix[i][j] == true) {
					MessageDisplay onLED = new MessageDisplay((30 - j), (30 - i));
					trueLEDList.add(onLED);
				}
			}
		}
		trueLEDArray = new MessageDisplay[trueLEDList.size()];
		trueLEDList.toArray(trueLEDArray);
		System.out.print("\nAmount of objects in trueLEDList = " + trueLEDList.size()
				+ "\nAmount of objects in trueLEDArray = " + trueLEDArray.length);

	}

	public static void printNodeData() {
		for (int i = 0; i < trueLEDArray.length; i++) {
			System.out.println("True node at (x,y): (" + trueLEDArray[i].x + ", " + trueLEDArray[i].y + ")");
		}
	}

	public static void main(String[] args) {

		userInputMatrix();
		findTrueLED();
		printNodeData();

		JPanel panel = new JPanel();
		JFrame jf = new JFrame();
		JLabel zSlider = new JLabel();
		JLabel speedLabel = new JLabel();
		jf.setLayout(new BorderLayout());
		jf.setSize(1920, 1080);
		jf.setTitle("Java Spatial Matrix Demonstration");
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ThesisDisplay td = new ThesisDisplay();
		orientation.setName("Z-Rotation");
		zSlider.setText("Z-Rotation 0 - 360 deg");
		orientation.setToolTipText("Set the orientation of the Z-Axis");
		speedLabel.setText("Wave Speed Time (ms)");
		panel.add(speedLabel, BorderLayout.WEST);
		panel.add(speed, BorderLayout.WEST);
		panel.add(zSlider, BorderLayout.EAST);
		panel.add(orientation, BorderLayout.EAST);
		jf.add(panel, BorderLayout.NORTH);
		jf.add(td);
		jf.setLocationRelativeTo(null);
		jf.setExtendedState(JFrame.MAXIMIZED_BOTH);
		jf.setUndecorated(true);
		jf.setBackground(Color.BLACK);
		jf.setVisible(true);

		tm.addActionListener(td);
		tm.setCoalesce(false);
		tm.start();
	}

}
