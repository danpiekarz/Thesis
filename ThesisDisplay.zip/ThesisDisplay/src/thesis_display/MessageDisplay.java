package thesis_display;


public class MessageDisplay {
	int x, y;

	MessageDisplay(int x, int y) {
			this.x = x*20;
			this.y = y*20;
		}
}
